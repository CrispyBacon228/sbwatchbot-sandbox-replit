#!/usr/bin/env python3
from sbwatch.app import build_levels
if __name__ == "__main__":
    build_levels()
