def current_front(symbol_hint: str) -> str:
    # TODO: map continuous to front-month
    return symbol_hint
