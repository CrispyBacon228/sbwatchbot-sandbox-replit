import logging, logging.config, yaml, os, sys
from loguru import logger as log

def setup_logging():
    # Try multiple possible paths for the logging config
    possible_paths = [
        "/opt/sb-watchbot/configs/logging.yaml",  # Original path
        "./configs/logging.yaml",  # Relative path
        "configs/logging.yaml",    # Alternative relative path
        "./src/sbwatch/infra/configs/logging.yaml"  # Fallback to infra config
    ]
    
    cfg = None
    for path in possible_paths:
        if os.path.exists(path):
            cfg = path
            break
    
    if cfg:
        with open(cfg, "r") as f:
            logging.config.dictConfig(yaml.safe_load(f))
    else:
        logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s %(name)s - %(message)s")

    class InterceptHandler(logging.Handler):
        def emit(self, record):
            try:
                level = log.level(record.levelname).name
            except Exception:
                level = record.levelno
            log.opt(depth=6, exception=record.exc_info).log(level, record.getMessage())

    for name in list(logging.root.manager.loggerDict.keys()):
        logging.getLogger(name).handlers = [InterceptHandler()]

    log.remove()
    log.add(sys.stdout, enqueue=True, level="INFO")
