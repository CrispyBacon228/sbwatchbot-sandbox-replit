# SB Watchbot - Trading Strategy Bot

## Overview
SB Watchbot is an automated market monitoring system for ICT-style trading strategies. It generates daily levels, watches live markets, and pushes trade alerts to Discord. This project has been successfully imported and configured to run in the Replit environment.

## Project Architecture
- **Language**: Python 3.11
- **Build System**: setuptools with pyproject.toml
- **CLI Framework**: Typer for command-line interface
- **Dependencies**: databento, loguru, pydantic, requests, httpx, pyyaml

## Core Features
- Daily levels generation (Asia, London, PDH/PDL) → saved to `./data/levels.json`
- ICT strategy alerts:
  - Detects liquidity sweeps + Fair Value Gaps
  - Entry rules limited to 10–11 ET kill zone
  - Take profit and stop-loss targets auto-calculated
  - Alerts filtered to avoid overlap
- Outputs alerts to:
  - Discord (via webhook)
  - CSV logs in `./out`

## Project Structure
```
src/sbwatch/           # Main package
├── cli/               # Command-line interface modules
├── config/           # Configuration settings
├── core/             # Core trading logic (alerts, signals, etc.)
├── engine/           # Live trading and replay engines
├── strategy/         # Trading strategies (ICT)
├── adapters/         # External integrations (databento, discord)
└── util/             # Utility modules

configs/              # Configuration files
├── settings.yaml     # Trading parameters
└── logging.yaml      # Logging configuration

out/                  # Output directory for CSV logs
data/                 # Data storage for levels
```

## Available Commands
- `sbwatch levels` - Build session levels (Asia, London, PDH/PDL)
- `sbwatch live` - Run live watcher and send Discord alerts
- `sbwatch notify` - Notification helpers
- `sbwatch replay` - Replay a past day and export alerts to CSV
- `sbwatch status` - Show sb-watchbot health/status
- `sbwatch ict` - ICT backtest / replay
- `sbwatch ict-explain` - Explain ICT detections for a day

## Configuration Requirements
The application requires API keys and configuration through environment variables:
- `DATABENTO_API_KEY` - Your API key for Databento (market data)
- `DISCORD_WEBHOOK_URL` - Discord webhook URL for alerts
- `FRONT_SYMBOL` - Trading symbol (default: NQU5)
- `POLL_SECONDS` - Polling interval for live data (default: 5)
- `COOLDOWN_SEC` - Cooldown periods for alerts (default: 300)
- `MARGIN_SEC` - Margin in seconds for data fetching (default: 900)
- `REPLAY_ET_DATE` - Date for replay functionality

## Replit Environment Setup
- Python 3.11 installed and configured
- All dependencies installed via pip
- Package installed in development mode (`pip install -e .`)
- Workflow configured to run status command for monitoring

## Usage Examples
```bash
# Show application status
sbwatch status show

# Run a replay for a specific date
sbwatch replay run --date 2025-09-26

# Show help for any command
sbwatch --help
sbwatch replay --help
```

## Recent Changes
- 2025-09-28: Initial import and setup in Replit environment
- Installed Python 3.11 and all required dependencies
- Configured CLI application and verified functionality
- Set up workflow for application monitoring

## Notes
- This is a command-line application designed for automated trading strategy monitoring
- Requires valid API keys for Databento and Discord integration to function fully
- The application can run in live mode or replay historical data
- All trading logic follows ICT (Inner Circle Trader) methodology